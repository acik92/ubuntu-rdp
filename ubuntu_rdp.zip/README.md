# Ubuntu + XFCE Desktop + RDP for GitHub Codespaces

### ✔ Ubuntu
### ✔ XFCE Desktop (lightweight)
### ✔ xRDP working on port 3389
### ✔ Auto setup on Codespaces

## Cara guna:
1. Upload repo ini ke GitHub
2. Tekan **Code → Create Codespace on Main**
3. Tunggu Codespace build
4. Bila siap, buka Remote Desktop (Windows)
5. Masukkan: `127.0.0.1:3389`

### Login:
- **Username:** ubuntu  
- **Password:** 123456

Siap 🎉
